﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace CGT
{
	[CreateAssetMenu(fileName = "GameDefaults", menuName = "Common Game Tools/Game Defaults", order = 1)]
	public class GameDefaults : ScriptableObject
	{
		//Default label values
		[Header("Player Transform")]
		public Transform player;

		//Default label values
		[Header("Default message values")]
		public Font messageFont;
		public int messageFontSize = 35;
		public Color messageFontColor = Color.white;
		public bool messageStroke = true;
		public Color messageStrokeColor = Color.black;

		//Default label values
		[Header("Default label values")]
		public Font labelFont;
		public int labelFontSize = 15;
		public Color labelFontColor = Color.white;
		public bool labelStroke = true;
		public Color labelStrokeColor = Color.black;

		//Default outline values
		[Header("Default outline values")]
		public Color outlineColor = Color.cyan;
		public bool outlineFlash = false;
		[Range(0, 10)]
		public float outlbeFlashSpeed;
	}
}
﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace CGT
{
	[CreateAssetMenu(fileName = "MenuTheme", menuName = "Common Game Tools/Menu Theme", order = 4)]
	public class MenuTheme : ScriptableObject
	{		
		public Sprite windowSprite;		
		public Sprite buttonSprite;
		public Sprite panelSprite;
		public Font MainFont;
		public Sprite backgroundSprite;
		public Color[] colorScheme= new Color[5];
	}
}
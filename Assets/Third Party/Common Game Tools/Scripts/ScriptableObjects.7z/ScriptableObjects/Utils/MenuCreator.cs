﻿using UnityEngine;
using UnityEditor;
using UnityEngine.UI;

namespace CGT
{
	public class MenuCreator
	{
		public static string head = "Head";
		public static string menuWindow = "menuWindow";

		public static void CreateMenuPrefab(MenuListView menu, string name, MenuTheme theme=null)
		{
			GameObject Menu = Resources.Load("MenuTemplate/MenuPrefab") as GameObject;
			GameObject instanceRoot = (GameObject) PrefabUtility.InstantiatePrefab(Menu);
			//instanceRoot.transform.localScale = new Vector3(1,1,1);

			CreateMenuButtons(menu, instanceRoot, null);

			string localPath = "Assets/Common Game Tools/GeneratedMenu/" + menu.menuRoot.Name + ".prefab";
			localPath = AssetDatabase.GenerateUniqueAssetPath(localPath);
			PrefabUtility.SaveAsPrefabAsset(instanceRoot, localPath);
			GameObject.DestroyImmediate(instanceRoot);			
		}

		public static void CreateMenuButtons(MenuListView menu, GameObject menuPrefab, GameObject parent)
		{
			string toSearch = "";
			if (parent != null)
				toSearch = parent.name;

			GameObject buttonRow= menuPrefab.transform.Find("Canvas/MenuButtons").gameObject;
			GameObject button = menuPrefab.transform.Find("Canvas/MenuButtons/Button").gameObject;

			GameObject newButtonRow = GameObject.Instantiate(buttonRow, menuPrefab.transform.Find("Canvas"));
			newButtonRow.name = "BaseButtons";

			int pos = menu.FindElement(0, toSearch);
			while (pos != -1)
			{
				GameObject newButton = GameObject.Instantiate(button, newButtonRow.transform);
				newButton.transform.Find("Button").gameObject.GetComponent<Text>().text=menu.menuItems[pos].Name;
				pos = menu.FindElement(pos + 1, toSearch);
			}
		}
	}	
}
﻿using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CGT
{
	[CustomEditor(typeof(MenuConfiguration))]
	public class MenuConfigurationEditor : Editor
	{
		public Vector2 scrollPosition;
		bool seeLegend = false;
		bool isActive = false;
		bool showFunctions = false;
		bool hideWarning = false;
		MenuListView treeView;

		private SerializedProperty listViewSerialized, menuName;

		void OnEnable()
		{
			listViewSerialized = serializedObject.FindProperty("treeView");
			menuName = serializedObject.FindProperty("menuName");
		}

		public override void OnInspectorGUI()
		{
			MenuConfiguration menuConfiguration = (MenuConfiguration)target;
			treeView = menuConfiguration.treeView;
			string oldName = menuConfiguration.menuName;
			GUIStyle myStyle = new GUIStyle();
			myStyle.fontSize = 20;
			EditorGUILayout.LabelField("Menu Configuration", myStyle);
			seeLegend = EditorGUILayout.Foldout(seeLegend, "Show Help", true);
			if (seeLegend)
				DrawLegend();
			Rect windowSize = Rect.zero;
			windowSize.height = 15 + treeView.TreeElements() * 20;
			scrollPosition = GUILayout.BeginScrollView(scrollPosition, EditorStyles.helpBox);			
			treeView.DrawGUILayout(windowSize.width, windowSize.height);
			GUILayout.Space(30f);
			GUILayout.EndScrollView();

			ButtonArea();
			/*			
			*/
			EditorUtils.ThinLine(1);

			GUIStyle style = new GUIStyle(EditorStyles.helpBox);
			style.richText = true;
			style.fontSize = 11;
			EditorGUILayout.TextArea("<b>GENERATE PREFAB</b>\nCreate a Menu prefab with all items created in menu editor. Use this prefab directly in your scene.", style);

			menuName.stringValue = EditorGUILayout.TextField("Prefab Name", menuName.stringValue);			
			menuName.serializedObject.ApplyModifiedProperties();
			treeView.RenameMenu(menuName.stringValue);

			EditorUtils.ThinLine(1);
			if (GUILayout.Button("Save Prefab", new GUILayoutOption[0]))
			{
				MenuCreator.CreateMenuPrefab(treeView, menuName.stringValue);
			}

			EditorUtility.SetDirty(target);			
		}		

		public void DrawLegend()
		{
			GUIStyle style = new GUIStyle(EditorStyles.helpBox);
			style.richText = true;
			style.fontSize = 11;

			//EditorGUI.HelpBox(new Rect(18,20,350,120),"", MessageType.None);
			//GUILayout.Box("", EditorStyles.helpBox, GUILayout.Height(180));
			EditorGUILayout.TextArea("<b>MENU EDITOR</b>\nUse the modificators to create, delete and move menu items. Click in any item name to edit the properties.", style);
			EditorGUILayout.LabelField("Menu Modificators", EditorStyles.boldLabel);
			GUILayout.BeginHorizontal();
			GUILayout.BeginVertical();
			DrawLegendItem(MenuListView.iconAdd, "Add Menu Item");
			DrawLegendItem(MenuListView.iconDelete, "Delete Menu Item");			
			GUILayout.EndVertical();
			GUILayout.BeginVertical();
			DrawLegendItem(MenuListView.iconUp, "Move Item Up");
			DrawLegendItem(MenuListView.iconDown, "Move Item Down");			
			GUILayout.EndVertical();
			GUILayout.EndHorizontal();
			
			EditorGUILayout.LabelField("Icon Legend", EditorStyles.boldLabel);
			GUILayout.BeginHorizontal();			
			DrawLegendItem(MenuListView.iconSubMenu, "Sub Menu");
			DrawLegendItem(MenuListView.iconOption, "Menu Window");	
			GUILayout.EndHorizontal();
			EditorUtils.ThinLine(1);
		}

		public void DrawLegendItem(Texture2D tx, string label)
		{
			GUILayout.BeginHorizontal();
			GUILayout.Label(tx);
			GUILayout.Label(label);
			GUILayout.FlexibleSpace();
			GUILayout.EndHorizontal();
		}

		private void ButtonArea()
		{
			GUILayout.BeginVertical();
			GUILayout.BeginHorizontal(new GUILayoutOption[0]);
			GUILayout.Space(10f);
			if (GUILayout.Button("Expand All", new GUILayoutOption[0]))			
			{
				treeView.OpenAll();
			}
			if (GUILayout.Button("Colapse All", new GUILayoutOption[0]))
			{
				treeView.CloseAll();
			}

			GUILayout.FlexibleSpace();
			if (GUILayout.Button("Expand All", new GUILayoutOption[0]))
			{
				treeView.OpenAll();
			}
			if (GUILayout.Button("Colapse All", new GUILayoutOption[0]))
			{
				treeView.CloseAll();
			}
			GUILayout.Space(10f);
			GUILayout.EndHorizontal();			
			GUILayout.EndVertical();
		}
	}
}
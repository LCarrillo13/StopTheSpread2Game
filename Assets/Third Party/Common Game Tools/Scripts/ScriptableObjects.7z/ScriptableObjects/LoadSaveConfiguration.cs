﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CGT
{
	[CreateAssetMenu(fileName = "LoadSaveConfiguration", menuName = "Common Game Tools/Load Save Configuration", order = 2)]
	public class LoadSaveConfiguration : ScriptableObject
	{
		public bool encryptData = true;
		public string password = "Set Your Own Password";
		public string salt = "Add Some Salt";
	}
}
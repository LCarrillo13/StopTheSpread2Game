﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;
#endif

namespace CGT
{
	[CreateAssetMenu(fileName = "MenuConfiguration", menuName = "Common Game Tools/Menu Configuration", order = 3)]
	public class MenuConfiguration : ScriptableObject
	{
		//public MenuTreeView treeView = new MenuTreeView("Main Menu", MenuTreeView.NodeType.MainMenu, false);
		public MenuListView treeView = new MenuListView("Sample Menu", false);

		public string menuName="Sample Menu";

		public enum MenuAnimations
		{
			NoAnimations,
			SimpleAnimations
		}

		public enum MenuLayout
		{
			LeftAlign,
			CenterAlign,
			RightAlign
		}

		public enum MenuTheme
		{
			Simple,
			SciFi,
			Dungeon,
			Modern,
			Militar
		}

		public string UID;

		private void OnEnable()
		{
			treeView.editing = false;
		}

		private void OnValidate()
		{
#if UNITY_EDITOR
			if (UID == "")
			{
				UID = GUID.Generate().ToString();
				UnityEditor.EditorUtility.SetDirty(this);
			}
#endif
			Debug.Log(UID);
		}

		public void LookForChanges()
		{
			string assetPath = AssetDatabase.GetAssetPath(this.GetInstanceID());
			Debug.Log(assetPath);
		}

		public bool encryptData = true;
		public string password = "Set Your Own Password";
		public string salt = "Add Some Salt";
	}
}
